// Place your preferences for xul-ext-noscript in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/noscript/defaults/preferences/noscript.js
