// Place your preferences for xul-ext-torbutton in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/torbutton/defaults/preferences/preferences.js
