// Place your preferences for xul-ext-cookie-monster in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/cookie-monster/defaults/preferences/defaults.js
