// Place your preferences for xul-ext-https-everywhere in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/https-everywhere/defaults/preferences/preferences.js
