// Place your preferences for xul-ext-foxyproxy-standard in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/foxyproxy-standard/defaults/preferences/prefs.js
